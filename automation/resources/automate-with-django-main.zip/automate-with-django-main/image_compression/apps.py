from django.apps import AppConfig


class ImageCompressionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "image_compression"
