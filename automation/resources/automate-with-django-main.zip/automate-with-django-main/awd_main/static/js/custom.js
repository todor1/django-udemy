setTimeout(function(){
    $('#messages').fadeOut('slow')
}, 5000)